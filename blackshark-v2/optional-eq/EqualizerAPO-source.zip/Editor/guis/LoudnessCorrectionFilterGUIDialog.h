/*
    This file is part of Equalizer APO, a system-wide equalizer.
    Copyright (C) 2017  Jonas Thedering

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#pragma once

#include <QBuffer>
#include <QDialog>

namespace Ui {
class LoudnessCorrectionFilterGUIDialog;
}

class LoudnessCorrectionFilterGUIDialog : public QDialog
{
	Q_OBJECT

public:
	explicit LoudnessCorrectionFilterGUIDialog(QWidget* parent = 0);
	~LoudnessCorrectionFilterGUIDialog();

	int getMeasuredLevel();

private slots:
	void on_playButton_clicked();
	void on_stopButton_clicked();

	void on_leftRadioButton_toggled(bool checked);
	void on_rightRadioButton_toggled(bool checked);
	void on_bothRadioButton_toggled(bool checked);

private:
	Ui::LoudnessCorrectionFilterGUIDialog* ui;
	QBuffer buffer;
};
