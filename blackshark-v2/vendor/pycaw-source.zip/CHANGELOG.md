# Change Log

## [Unreleased]

### Added

- Add Mypy enforcement and initial annotations for constants and high-level utility wrappers
- Expand Mypy coverage to public callback adapters and subclass hooks

## [20260927]

### Fixed

- Keep installed-wheel smoke validation synchronized with project metadata (@AndreMiras)

## [20260926]
    - Drop Python 3.8 and 3.9, support Python 3.10-3.14, and declare tested comtypes 1.4.8 and psutil 5.9.0 minimum versions (@AndreMiras)
    - Modernize packaging and development with PEP 621, Ruff, locked uv/Tox tooling, installed-wheel validation, and PyPI Trusted Publishing (@AndreMiras)

## [20260921]
    - Add AudioDevice.volume_percent property for percentage-based master volume, refs #13, #109 (@ahmetberber)
    - Improve PROPVARIANT compatibility, device friendly-name fallback, and default-device switching on older Windows versions, refs #108 (@AndreMiras)
    - Fix endpoint and session callbacks for devices with variable channel counts, including more than eight channels (@AndreMiras)
    - Fix Magic callbacks when volume and mute change in the same notification (@AndreMiras)
    - Fix audio session callback unregistration and re-registration, refs #99 (@AndreMiras)
    - Handle audio session processes that exit during Magic session discovery (@AndreMiras)
    - Add Sphinx documentation, API and example references, and GitHub Pages publishing (@AndreMiras)
    - Document System Sounds sessions having no associated process, refs #14 (@AndreMiras)
    - Make example tests deterministic and prevent them from changing host audio state, refs #65 (@AndreMiras)
    - Improve CI reliability, linting, and automated dependency maintenance (@AndreMiras)
    - Update documentation and GitHub Actions dependencies, refs #110, #111, #113, #114, #116, #117 (@dependabot)

## [20251023]
    - Add SetDefaultDevice functionality to switch default audio devices, refs #49, #103 (@bdieudonne)
    - Add policyconfig API module (IPolicyConfig) for device management, refs #103 (@bdieudonne)
    - Add GetAllDevices() filters for data_flow and device_state, refs #103 (@bdieudonne)
    - Update GetSpeakers() to return AudioDevice type for consistency, refs #103 (@bdieudonne)
    - Add list_and_switch_devices_example.py, refs #103 (@bdieudonne)
    - Correct API definitions in audioclient and constants, refs #102 (@gexgd0419)
    - Update README to clarify Windows-only support, refs #94, #95 (@AndreMiras)
    - Update examples and tests (@bdieudonne)
    - Code quality improvements (@AndreMiras)

## [20240210]
    - fix double free due to using cast rather than QueryInterface, refs #74 (@mrob95)
    - add: example for IMMNotificationClient, refs #77 (@Invisi)
    - IChannelAudioVolume support, refs #87 (@mltony)
    - Format fix (@AndreMiras), refs #89
    - GitHub Actions versions bumps (@AndreMiras), refs #88
    - Bump Python versions (@AndreMiras), refs #90
    - Fix CI virtual audio install (@AndreMiras), refs #91

## [20230407]
    - Fixes memory leak from PROPVARIANT, refs #72 (@KillerBOSS2019)

## [20230322]
    - CI and testing improvements
    - Improve audioclient, audiopolicy and mmdeviceapi support, refs #70 (@dot-Eagle96)
    - Fix IPropertyStore.SetValue parameters, refs #71 (@Invisi)

## [20220416]
    - Migrate to GitHub Actions
    - CI tests via virtual sound card
    - Drop Python 2.7 and 3.6
    - Add support for 3.7 up to 3.10
    - Fix missing api package, refs #63 (@Jan-Zeiseweis)
    - Automatic PyPI release on tagging, refs #44

## [20210516]
    - Fixed GetAllDevices() COMError, refs #15, #28 and #30 (@micolous and @reversefold)
    - New IAudioSessionEvents callbacks support, refs #27, #36 (@TurboAnonym)
    - IAudioSessionControl GetState fix, refs #32, #37 (@TurboAnonym)
    - Adding AudioUtilities.GetMicrophone(), refs #39 (@alebzk)
    - Reorganize / Split the pycaw.pycaw file in modules and subpackages, refs #38 (@TurboAnonym)
    - OnSessionCreated support + Wrapper for callbacks, refs #40 (@TurboAnonym)
    - "Magic" module, easy session control, refs #42 (@TurboAnonym)

## [20190904]
    - Fixed enum34 dependency, refs #17 (@mmxfguerin)

## [20181226]
    - GetVolumeStepInfo() interface fixes
    - Added AudioController class example, refs #4 (@lorenzsj)
    - IAudioEndpointVolumeCallback::OnNotify support, refs #10, #11 (@csevast)
    - Setup (limited) continuous testing, refs #12

## [20160929]
    - Fixed crash on print AudioDevice & AudioSession on Python3
    - Fixed GetAllSessions() reliability, refs #1

## [20160508]
    - Fixed enum requirement
    - Unit tested examples:
        - audio_endpoint_volume_example
        - simple_audio_volume_example
        - volume_by_process_example
    - Added Tox testing framework support
    - Added pyflakes passive checker to tests
    - Testing style convention using pep8
    - Ported code to Python3

## [20160507]
    - Implemented new interfaces:
        - PROPVARIANT
        - IPropertyStore
        - SimpleAudioVolume
        - IAudioClient
    - Added GetAllDevices() helper method
    - Added code examples:
        - audio_endpoint_volume_example
        - simple_audio_volume_example
        - volume_by_process_example

## [20160424]
    - Initial release
